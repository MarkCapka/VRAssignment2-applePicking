# VRAssignment2-applePicking
CSCD477 - Assignment 2 Apple Picking in a Tangible Virtual Environment

Assignment 2:

Note: openHaptics folder needs to be downloaded and imported 
  Window -> asset store -> search for OpenHaptics and download
  
  Likely need to import scene, may have to reset the terrain 
    gameObject -> 3dObject -> terrain 
    
   
Already have apple prefab (i think set up correctly)
 
 Bowl is touchable & isKinematic = true (so it can't move)
 
 Apples are touchable 
